#pragma warning(disable:4996)
#include <stdio.h>
#define CLA 3
#define STU 5

int main(void) {
	int score[CLA][STU] = {
		{50, 60, 70, 80, 90},
		{55, 65, 75, 85, 95},
		{57, 67, 87, 97, 100},
	};
	int class, stud;
	double total, subtotal;
	total = 0;

	for (class = 0; class < CLA; class++) {
		subtotal = 0;
		for (stud = 0; stud < STU; stud++)
			subtotal += score[class][stud];
		printf("�б� %d�� ��� ���� = %.2f\n", class+1, subtotal/STU);
		total += subtotal;
	}
	printf("��ü �л����� ��� ���� = %.2f\n", total/(CLA*STU));

	
	

	getchar();
	getchar();
	return 0;
}