#pragma warning(disable:4996)
#include <stdio.h>
#define ROWS 3
#define COLS 3

int main(void) {

	char str[] = "C programming";
	int i = 0;

	while (str[i] != '\0') i++;

	printf("���ڿ�  \"%s\"�� ���� : %d\n", str, i);




	getchar();
	getchar();
	return 0;
}

